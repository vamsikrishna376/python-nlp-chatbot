# Python NLP Chatbot

A beginner-friendly desktop chatbot built with **Python**, **NLTK**, and **Tkinter**.

## Features
- Simple natural-language message matching using tokenization and word overlap.
- Answers basic questions about Python and NLP.
- Responds to greetings and thanks.
- Gives the current date and time.
- Performs simple arithmetic (`12 + 5`, `calculate 8 * 4`).
- Graphical chat window with a message box and Send button.
- Includes a fallback tokenizer if NLTK is not installed.

## Requirements
- Python 3.9 or newer recommended.
- Tkinter (usually included with standard Python installations).
- NLTK (optional fallback is built in).

## Installation and execution

1. Extract the ZIP file.
2. Open the project folder in VS Code.
3. Open the terminal in that folder.
4. Install the dependency:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Run the chatbot:

   ```bash
   python chatbot.py
   ```

On some Windows installations, use `py` instead of `python`:

```bash
py -m pip install -r requirements.txt
py chatbot.py
```

## Example messages
- `Hello`
- `What is Python?`
- `Explain NLP`
- `What time is it?`
- `What is 12 * 5?`
- `Thank you`
- `Bye`

## Project structure

```text
python_nlp_chatbot/
├── chatbot.py
├── requirements.txt
└── README.md
```

## How it works
1. The user types a message in the Tkinter window.
2. NLTK tokenizes the message into words.
3. The program compares those words with example patterns for each intent.
4. The best matching intent is selected if its score reaches the matching threshold.
5. A response is displayed in the chat window. If no intent matches, the chatbot gives a fallback response.

## Limitations and future improvements
This is an educational, rule-based NLP chatbot, not a large language model. It may misunderstand sentences that differ significantly from its sample patterns. Future versions could add more intents, a larger FAQ dataset, spaCy-based entity recognition, speech input, or a web interface.
