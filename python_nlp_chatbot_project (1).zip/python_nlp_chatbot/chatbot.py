"""
Python NLP Chatbot
A beginner-friendly desktop chatbot using NLTK and Tkinter.
Run: python chatbot.py
"""

import random
import re
from datetime import datetime

try:
    from nltk.tokenize import wordpunct_tokenize
except ImportError:
    wordpunct_tokenize = None


INTENTS = [
    {
        "name": "greeting",
        "patterns": ["hello", "hi", "hey", "good morning", "good evening"],
        "responses": [
            "Hello! How can I help you today?",
            "Hi there! Ask me a question.",
            "Hey! What would you like to know?"
        ],
    },
    {
        "name": "name",
        "patterns": ["what is your name", "who are you", "your name"],
        "responses": ["I'm Python NLP Chatbot, your simple virtual assistant."],
    },
    {
        "name": "python",
        "patterns": ["what is python", "tell me about python", "python language"],
        "responses": [
            "Python is a popular, beginner-friendly programming language "
            "used in web development, automation, data science and AI."
        ],
    },
    {
        "name": "nlp",
        "patterns": ["what is nlp", "natural language processing", "explain nlp"],
        "responses": [
            "NLP stands for Natural Language Processing. It helps computers "
            "process and understand human language."
        ],
    },
    {
        "name": "help",
        "patterns": ["help", "what can you do", "your features"],
        "responses": [
            "I can answer basic questions about Python and NLP, tell you the "
            "date and time, and do simple calculations. Try asking!"
        ],
    },
    {
        "name": "thanks",
        "patterns": ["thank you", "thanks", "thank you very much"],
        "responses": ["You're welcome!", "Happy to help!", "No problem."],
    },
    {
        "name": "goodbye",
        "patterns": ["bye", "goodbye", "see you", "exit", "quit"],
        "responses": ["Goodbye! Have a great day.", "See you next time!"],
    },
]


def tokenize(text):
    """Tokenize text with NLTK when installed; otherwise use a safe fallback."""
    if wordpunct_tokenize:
        tokens = wordpunct_tokenize(text.lower())
    else:
        tokens = re.findall(r"[a-z0-9']+", text.lower())
    return [token for token in tokens if re.search(r"[a-z0-9]", token)]


def similarity(user_text, pattern):
    """Simple token-overlap score for matching a user message to a pattern."""
    user_tokens = set(tokenize(user_text))
    pattern_tokens = set(tokenize(pattern))
    if not user_tokens or not pattern_tokens:
        return 0.0
    return len(user_tokens & pattern_tokens) / len(pattern_tokens)


def get_response(message):
    """Return a response based on matched intent or built-in utility commands."""
    cleaned = message.strip()
    if not cleaned:
        return "Please type a message so I can help."

    lower = cleaned.lower()

    # Utility features
    if re.search(r"\b(time|current time)\b", lower):
        return "The current time is " + datetime.now().strftime("%I:%M %p") + "."
    if re.search(r"\b(date|today's date|today date)\b", lower):
        return "Today's date is " + datetime.now().strftime("%d %B %Y") + "."

    # Safe, basic arithmetic: e.g. calculate 12 * 4
    calc_match = re.search(
        r"(?:calculate|what is|solve)?\s*(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)",
        lower
    )
    if calc_match:
        a, operator, b = calc_match.groups()
        a, b = float(a), float(b)
        if operator == "+":
            result = a + b
        elif operator == "-":
            result = a - b
        elif operator == "*":
            result = a * b
        else:
            if b == 0:
                return "A number cannot be divided by zero."
            result = a / b
        result = int(result) if result.is_integer() else result
        return f"The answer is {result}."

    best_intent = None
    best_score = 0.0
    for intent in INTENTS:
        for pattern in intent["patterns"]:
            score = similarity(cleaned, pattern)
            if score > best_score:
                best_score = score
                best_intent = intent

    # Require a reasonable match to avoid unrelated accidental matches.
    if best_intent and best_score >= 0.5:
        return random.choice(best_intent["responses"])

    return (
        "I'm not sure I understood that. Try asking about Python, NLP, "
        "the date, the time, or a simple calculation. Type 'help' for ideas."
    )


def main():
    """Start the desktop chat interface."""
    import tkinter as tk
    from tkinter.scrolledtext import ScrolledText

    root = tk.Tk()
    root.title("Python NLP Chatbot")
    root.geometry("650x560")
    root.minsize(480, 400)

    heading = tk.Label(
        root, text="Python NLP Chatbot",
        font=("Arial", 18, "bold"), pady=12
    )
    heading.pack()

    chat_area = ScrolledText(
        root, wrap=tk.WORD, font=("Arial", 11),
        state="disabled", padx=10, pady=10
    )
    chat_area.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)

    input_frame = tk.Frame(root)
    input_frame.pack(fill=tk.X, padx=12, pady=12)

    message_entry = tk.Entry(input_frame, font=("Arial", 11))
    message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=7)

    def add_message(sender, message):
        chat_area.configure(state="normal")
        chat_area.insert(tk.END, f"{sender}: {message}\n\n")
        chat_area.configure(state="disabled")
        chat_area.see(tk.END)

    def send_message(event=None):
        message = message_entry.get().strip()
        if not message:
            return
        add_message("You", message)
        message_entry.delete(0, tk.END)
        response = get_response(message)
        add_message("Bot", response)
        if message.lower() in {"bye", "goodbye", "exit", "quit"}:
            root.after(1200, root.destroy)

    send_button = tk.Button(
        input_frame, text="Send", command=send_message,
        font=("Arial", 10, "bold"), padx=18
    )
    send_button.pack(side=tk.LEFT, padx=(8, 0))

    message_entry.bind("<Return>", send_message)
    add_message("Bot", "Hello! I'm your Python NLP chatbot. Type 'help' to get started.")
    message_entry.focus_set()

    root.mainloop()


if __name__ == "__main__":
    main()
